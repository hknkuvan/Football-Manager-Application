
import java.util.ArrayList;
import java.util.Scanner;

public class SimulateSystem {

    public static void main(String[] args) {
        TransferBoard transferBoard = new TransferBoard();
        Scanner scanner = new Scanner(System.in);
        boolean start = false;

        while (!start) {
            System.out.println("1- List all Players in the system.");
            System.out.println("2- List all Teams in the system.");
            System.out.println("3- List all teamless players.");
            System.out.println("4- Establish a contract between a player and a team.");
            System.out.println("5- Terminate the existing contract between a player and a team.");
            System.out.println("6- Exit.");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();
            switch (choice) {
                case 1:
                    System.out.println("Players in the system:");
                    ArrayList<Player> players = transferBoard.getPlayers();
                    for (int i = 0; i < players.size(); i++) {
                        Player player = players.get(i);
                        System.out.println(player);
                    }
                    break;

                case 2:

                    System.out.println("Teams in the system:");
                    ArrayList<Team> teams = transferBoard.getTeams();
                    for (int i = 0; i < teams.size(); i++) {
                        Team team = teams.get(i);
                        double totalValue = transferBoard.calculateTeamTotalValue(team.getShortName());
                        System.out.println(team.getShortName() + ", Total Value: " + totalValue + ", Size: " + team.getSize());
                    }
                    break;

                case 3:
                    System.out.println("Teamless players:");
                    boolean hasTeamlessPlayers = false;
                    for (int i = 0; i < transferBoard.getPlayers().size(); i++) {
                        Player player = transferBoard.getPlayers().get(i);
                        if (player.getCurrentTeam() == null) {
                            System.out.println(player.getName());
                            hasTeamlessPlayers = true;
                        }
                    }
                    if (!hasTeamlessPlayers) {
                        System.out.println("No teamless players.");
                    }
                    break;

                case 4:
                    System.out.print("Enter player name, team name, contract type, and contract value (e.g., Icardi GS Permanent 1000000): ");
                    String contractInfoInput = scanner.nextLine();

                    String[] contractInfo = contractInfoInput.split("\\s+");// bölüyor

                    if (contractInfo.length == 4) {

                        double contractValue = Double.parseDouble(contractInfo[3]); // double değer döndürüyor

                        String result = transferBoard.makeContract(contractInfo[0], contractInfo[1], contractInfo[2], contractValue);

                        System.out.println(result);
                    } else {

                        System.out.println("Invalid input.");
                    }
                    break;
                case 5:
                    System.out.print("Enter player name and team name to terminate the contract (e.g., Icardi GS): ");
                    String[] terminationInfo = scanner.nextLine().split(" ");
                    if (terminationInfo.length == 2) {
                        transferBoard.terminateContract(terminationInfo[0], terminationInfo[1]);
                        System.out.println("Contract terminated successfully.");
                    } else {
                        System.out.println("Invalid input.");
                    }
                    break;
                case 6:
                    start = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please choose again.");
            }
        }

        System.out.println("Player Contracts:");
        ArrayList<Contract> contracts = transferBoard.getContracts();
        for (int i = 0; i < contracts.size(); i++) {
            Contract contract = contracts.get(i);
            System.out.println(contract.getPlayer().getName() + " : " + contract.getValue() + " " + contract.getTeam().getShortName());
        }

        System.out.println("Team Information:");
        ArrayList<Team> teams = transferBoard.getTeams();
        for (int i = 0;
                i < teams.size(); i++) {
            Team team = teams.get(i);
            System.out.println(team.getShortName() + " : " + team.getTotalValue() + " " + team.getSize());
        }

        System.out.println("Teamless Players:");
        ArrayList<Player> players = transferBoard.getPlayers();
        boolean hasTeamlessPlayers = false;
        for (int i = 0; i < players.size();
                i++) {
            Player player = players.get(i);
            if (player.getCurrentTeam() == null) {
                System.out.println(player.getName());
                hasTeamlessPlayers = true;
            }
        }
        if (!hasTeamlessPlayers) {
            System.out.println("No teamless players.");
        }

    }
}
