/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Hakan KUVAN
 */
class Team {

    private String shortName;
    private String fullName;
    double totalValue;
    private int size;
    public static final int maxTeamSize = 22;

    public Team(String shortName, String fullName) {
        this.shortName = shortName;
        this.fullName = fullName;
        this.totalValue = 0; // Başlangıçta toplam değer sıfır olarak ayarlanır
        this.size = 22;
    }

    public String getShortName() {
        return shortName;
    }

    public String getFullName() {
        return fullName;
    }

    public double getTotalValue() {
        return totalValue;
    }

    public int getSize() {
        return size;
    }

    @Override
    public String toString() {
        return shortName + ", name=" + fullName + ", value: " + totalValue + ", size: " + size;
    }

    public void setTotalValue(double totalValue) {
        this.totalValue = totalValue;
    }

    public void setSize(int size) {
        this.size = size;
    }

    
}
