
import java.util.ArrayList;

public class TransferBoard {

    private ArrayList<Contract> contracts;
    private ArrayList<Player> players;
    private ArrayList<Team> teams;

    public TransferBoard() {
        contracts = new ArrayList<>();
        players = new ArrayList<>();
        teams = new ArrayList<>();
        populatePlayers();
        populateTeams();

    }

    public void populatePlayers() {
        String[] playerData = {
            "Muslera", "1", "Goalkeeper", "1800000", // Muslera için market value 1.80 milyon
            "Kaan", "22", "Defence", "5000000", // Kaan Ayhan için market value 5 milyon
            "Toreira", "34", "Midfield", "15000000", // Toreira için market value 15 milyon
            "Icardi", "9", "Forward", "18000000", // Icardi için market value 18 milyon
            "Kerem", "7", "Midfield", "17000000", // Kerem için market value 17 milyon
            "Abdulkerim", "17", "Defence", "9500000", // Abdulkerim için market value 9.5 milyon
            "Oliveira", "20", "Midfield", "3500000", // Oliveira için market value 3.5 milyon
            "Mertens", "10", "Midfield", "1800000", // Mertens için market value 1.8 milyon
            "Bakambu", "99", "Forward", "2800000", // Bakambu için market value 2.8 milyon
            "Nellson", "25", "Defence", "15000000", // Nellson için market value 15 milyon
            "Boey", "2", "Defence", "22000000" // Boey için market value 22 milyon
        };

        for (int i = 0; i < playerData.length; i += 4) {
            String name = playerData[i];
            int backNumber = Integer.valueOf(playerData[i + 1]); //Dizeyi Tamsayıya dönüştürmek için kullanılır
            String position = playerData[i + 2];
            double marketValue = Double.valueOf(playerData[i + 3]); // Dizeyi doublea dönüştürmek için kullanılır

            Player player = new Player(name, backNumber, position);
            player.setMarketValue(marketValue);
            players.add(player);
        }
    }

    public void populateTeams() {
        String[] teamData = {
            "Galatasaray", "GS",
            "Fenerbahce", "FB",
            "Besiktas", "BJK",
            "Trabzonspor", "TS",
            "Ankaragucu", "ANK",
            "Basaksehir", "BSK",
            "Karagumruk", "KGM"
        };

        for (int i = 0; i < teamData.length; i += 2) {
            Team team = new Team(teamData[i + 1], teamData[i]);
            teams.add(team);
        }
    }

    public String makeContract(String playerName, String teamName, String contractType, double contractValue) {

        Player player = null;
        for (int i = 0; i < players.size(); i++) {
            if (players.get(i).getName().equals(playerName)) {
                player = players.get(i);
                break;
            }
        }

        Team team = null;
        for (int i = 0; i < teams.size(); i++) {
            if (teams.get(i).getShortName().equals(teamName)) {
                team = teams.get(i);
                break;
            }
        }

        if (player == null) {
            return "UnknownPlayer";
        }
        if (team == null) {
            return "UnknownTeam";
        }
        if (team.getSize() >= Team.maxTeamSize) {
            return "ExceedingMaxNumPlayers";
        }

        boolean existingContract = false;
        for (int i = 0; i < contracts.size(); i++) {
            Contract c = contracts.get(i);
            if (c.getPlayer().equals(player) && c.getTeam().equals(team)) {
                existingContract = true;
                break;
            }
        }
        if (existingContract) {
            return "ExistingContract";
        }

        boolean rentedContract = false;
        for (int i = 0; i < contracts.size(); i++) {
            Contract c = contracts.get(i);
            if (c.getPlayer().equals(player) && c.getType().equals("Rented")) {
                rentedContract = true;
                break;
            }
        }
        if (rentedContract) {
            return "ContractNotPossible";
        }

        if (player.getCurrentTeam() == null && contractType.equals("Permanent")) {
            return "InvalidContractType";
        } else if (player.getCurrentTeam() != null && !contractType.equals("Permanent")) {
            return "InvalidContractType";
        }
        for (int i = 0; i < contracts.size(); i++) {
            Contract c = contracts.get(i);
            if (c.getPlayer().equals(player)) {
                contracts.remove(i);
                player.setPreviousTeam(player.getCurrentTeam());
                player.setCurrentTeam(null);
                player.setMarketValue(contractValue);
                break;
            }
        }

        Contract newContract = new Contract(player, team, contractType, contractValue);
        contracts.add(newContract);
        player.setCurrentTeam(team);
        player.setMarketValue(contractValue);
        team.setSize(team.getSize() + 1);
        team.setTotalValue(team.getTotalValue() + contractValue);
        return "SuccessfullyContracted";
    }

    public void terminateContract(String playerName, String teamName) {

        Player player = null;
        for (int i = 0; i < players.size(); i++) {
            Player p = players.get(i);
            if (p.getName().equals(playerName)) {
                player = p;
                break;
            }
        }

        Team team = null;
        for (int i = 0; i < teams.size(); i++) {
            Team t = teams.get(i);
            if (t.getShortName().equals(teamName)) {
                team = t;
                break;
            }
        }

        if (player == null || team == null) {
            return;
        }

        Contract contractToRemove = null;
        for (int i = 0; i < contracts.size(); i++) {
            Contract c = contracts.get(i);
            if (c.getPlayer().equals(player) && c.getTeam().equals(team)) {
                contractToRemove = c;
                break;
            }
        }

        if (contractToRemove == null) {
            return;
        }

        contracts.remove(contractToRemove);
        player.setCurrentTeam(player.getPreviousTeam());
        player.setMarketValue(0);
        player.setPreviousTeam(null);

        if (contractToRemove.getType().equals("Rented")) {
            Contract newContract = new Contract(player, player.getPreviousTeam(), "Permanent", player.getMarketValue());
            contracts.add(newContract);
            player.setCurrentTeam(player.getPreviousTeam());
            player.setMarketValue(player.getMarketValue());
            player.setPreviousTeam(null);
            player.getCurrentTeam().setSize(player.getCurrentTeam().getSize() + 1);
            player.getCurrentTeam().setTotalValue(player.getCurrentTeam().getTotalValue() + player.getMarketValue());
        } else {
            player.setCurrentTeam(null);
            team.setSize(team.getSize() - 1);
            team.setTotalValue(team.getTotalValue() - contractToRemove.getValue());
        }
    }

    public ArrayList<Contract> getContracts() {
        return contracts;
    }

    public double calculateTeamTotalValue(String teamShortName) {
        double totalValue = 0;
        for (int i = 0; i < contracts.size(); i++) {
            Contract contract = contracts.get(i);
            if (contract.getTeam().getShortName().equals(teamShortName)) {
                totalValue += contract.getValue();
            }
        }
        return totalValue;

    }

    public void setContracts(ArrayList<Contract> contracts) {
        this.contracts = contracts;
    }

    public ArrayList<Player> getPlayers() {
        return players;
    }

    public void setPlayers(ArrayList<Player> players) {
        this.players = players;
    }

    public ArrayList<Team> getTeams() {
        return teams;

    }

    public void setTeams(ArrayList<Team> teams) {
        this.teams = teams;
    }

}
