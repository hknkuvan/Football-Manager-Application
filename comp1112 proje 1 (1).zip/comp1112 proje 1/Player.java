/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Hakan KUVAN
 */
public class Player {

    private int backNumber;
    private String name;
    private String position;
    private double marketValue;
    private Team currentTeam;
    private Team previousTeam;

    public Player(String name, int backNumber, String position) {
        this.name = name;
        this.backNumber = backNumber;
        this.position = position;
    }

    public int getBackNumber() {
        return backNumber;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return name + ", backNumber=" + backNumber + ", position=" + position + ", marketValue=" + marketValue;
    }

    public String getPosition() {
        return position;
    }

    public double getMarketValue() {
        return marketValue;
    }

    public void setMarketValue(double marketValue) {
        this.marketValue = marketValue;
    }

    public Team getCurrentTeam() {
        return currentTeam;
    }

    public void setCurrentTeam(Team currentTeam) {
        this.currentTeam = currentTeam;
    }

    public Team getPreviousTeam() {
        return previousTeam;
    }

    public void setPreviousTeam(Team previousTeam) {
        this.previousTeam = previousTeam;
    }

}
